// ============================================================
//  customize.js — Kustomisasi Tampilan Barakatak Dashboard
// ============================================================

const EMOJI_OPTIONS = [
  "◈","★","⚡","🏆","🎯","🔥","💡","🌟","🚀","⚙️",
  "📌","🎪","🛡️","📊","💼","🎓","🌿","🌀","🔷","🦅",
];

const THEME_PRESETS = [
  { name: "Hijau Hutan",  header: "#1A3A2A", accent: "#D4A843", bg: "#F5F0E8", btn: "#2D5A3D" },
  { name: "Biru Laut",    header: "#1A2A4A", accent: "#4FC3F7", bg: "#EFF6FF", btn: "#1565C0" },
  { name: "Merah Bata",   header: "#4A1010", accent: "#F0A843", bg: "#FEF5EC", btn: "#C0392B" },
  { name: "Ungu Elegan",  header: "#2D1B4A", accent: "#C084FC", bg: "#F5F0FA", btn: "#7C3AED" },
  { name: "Abu Modern",   header: "#1C1C1E", accent: "#F59E0B", bg: "#F4F4F5", btn: "#374151" },
  { name: "Tosca Segar",  header: "#0F3D38", accent: "#34D399", bg: "#ECFDF5", btn: "#065F46" },
  { name: "Oranye Hangat",header: "#3A1800", accent: "#FB923C", bg: "#FFF7ED", btn: "#C2410C" },
  { name: "Pink Bold",    header: "#3B0A2A", accent: "#F472B6", bg: "#FDF2F8", btn: "#BE185D" },
];

// ── State ──────────────────────────────────────────────────
let custState = {
  appName:     "",
  subtitle:    "",
  tab1: "", tab2: "", tab3: "",
  logoType:    "icon",   // "icon" | "image"
  logoIcon:    "◈",
  logoImage:   "",       // base64
  colorHeader: "#1A3A2A",
  colorAccent: "#D4A843",
  colorBg:     "#F5F0E8",
  colorBtn:    "#2D5A3D",
};

// ── Load on init ───────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  loadCustFromStorage();
  buildEmojiGrid();
  buildPresetGrid();
  applyToPage(custState);
});

function loadCustFromStorage() {
  try {
    const saved = localStorage.getItem("barakatak_customize");
    if (saved) {
      custState = { ...custState, ...JSON.parse(saved) };
    }
  } catch(e) {}
}

function saveCustToStorage() {
  localStorage.setItem("barakatak_customize", JSON.stringify(custState));
}

// ── Open / Close Modal ─────────────────────────────────────
function openCustomizeModal() {
  // Sync form fields from current state
  document.getElementById("custAppName").value  = custState.appName;
  document.getElementById("custSubtitle").value = custState.subtitle;
  document.getElementById("custTab1").value     = custState.tab1;
  document.getElementById("custTab2").value     = custState.tab2;
  document.getElementById("custTab3").value     = custState.tab3;

  document.getElementById("custColorHeader").value    = custState.colorHeader;
  document.getElementById("custColorHeaderHex").value = custState.colorHeader;
  document.getElementById("custColorAccent").value    = custState.colorAccent;
  document.getElementById("custColorAccentHex").value = custState.colorAccent;
  document.getElementById("custColorBg").value        = custState.colorBg;
  document.getElementById("custColorBgHex").value     = custState.colorBg;
  document.getElementById("custColorBtn").value       = custState.colorBtn;
  document.getElementById("custColorBtnHex").value    = custState.colorBtn;

  // Logo preview in modal
  syncLogoPreviewModal();

  // Highlight active preset
  updatePresetHighlight();

  // Live preview
  syncHeaderPreview();

  document.getElementById("customizeModal").classList.remove("hidden");
}

function closeCustomizeModal(e) {
  if (e.target === document.getElementById("customizeModal")) closeCustomizeModalDirect();
}
function closeCustomizeModalDirect() {
  document.getElementById("customizeModal").classList.add("hidden");
}

// ── Emoji Grid ─────────────────────────────────────────────
function buildEmojiGrid() {
  const grid = document.getElementById("emojiGrid");
  grid.innerHTML = "";
  EMOJI_OPTIONS.forEach(emoji => {
    const btn = document.createElement("div");
    btn.className = "emoji-opt" + (custState.logoIcon === emoji && custState.logoType === "icon" ? " selected" : "");
    btn.textContent = emoji;
    btn.title = "Pilih " + emoji;
    btn.onclick = () => selectEmoji(emoji);
    grid.appendChild(btn);
  });
}

function selectEmoji(emoji) {
  custState.logoIcon  = emoji;
  custState.logoType  = "icon";
  custState.logoImage = "";
  buildEmojiGrid();
  syncLogoPreviewModal();
  syncHeaderPreview();
}

function resetLogo() {
  custState.logoIcon  = "◈";
  custState.logoType  = "icon";
  custState.logoImage = "";
  document.getElementById("logoFileInput").value = "";
  buildEmojiGrid();
  syncLogoPreviewModal();
  syncHeaderPreview();
}

// ── Logo Upload ────────────────────────────────────────────
function handleLogoUpload(e) {
  const file = e.target.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) {
    showToast("⚠️ File terlalu besar! Maks 2MB."); return;
  }
  const reader = new FileReader();
  reader.onload = (ev) => {
    custState.logoImage = ev.target.result;
    custState.logoType  = "image";
    syncLogoPreviewModal();
    syncHeaderPreview();
    buildEmojiGrid(); // deselect emoji
  };
  reader.readAsDataURL(file);
}

// ── Sync logo preview inside modal ─────────────────────────
function syncLogoPreviewModal() {
  const box   = document.getElementById("logoPreviewBox");
  const icon  = document.getElementById("logoPreviewIcon");
  const img   = document.getElementById("logoPreviewImg");
  if (custState.logoType === "image" && custState.logoImage) {
    icon.style.display = "none";
    img.src = custState.logoImage;
    img.style.display = "block";
  } else {
    icon.style.display = "block";
    icon.textContent   = custState.logoIcon;
    img.style.display  = "none";
  }
}

// ── Preset Grid ────────────────────────────────────────────
function buildPresetGrid() {
  const grid = document.getElementById("presetGrid");
  grid.innerHTML = "";
  THEME_PRESETS.forEach((p, i) => {
    const chip = document.createElement("div");
    chip.className = "preset-chip";
    chip.id = "preset-" + i;
    chip.innerHTML = `
      <div class="preset-dots">
        <div class="preset-dot" style="background:${p.header}"></div>
        <div class="preset-dot" style="background:${p.accent}"></div>
        <div class="preset-dot" style="background:${p.bg};border:1px solid #ccc"></div>
      </div>
      <span>${p.name}</span>
    `;
    chip.onclick = () => applyPreset(p, i);
    grid.appendChild(chip);
  });
}

function applyPreset(p, idx) {
  document.getElementById("custColorHeader").value    = p.header;
  document.getElementById("custColorHeaderHex").value = p.header;
  document.getElementById("custColorAccent").value    = p.accent;
  document.getElementById("custColorAccentHex").value = p.accent;
  document.getElementById("custColorBg").value        = p.bg;
  document.getElementById("custColorBgHex").value     = p.bg;
  document.getElementById("custColorBtn").value       = p.btn;
  document.getElementById("custColorBtnHex").value    = p.btn;
  updatePresetHighlight(idx);
  previewTheme();
}

function updatePresetHighlight(activeIdx) {
  document.querySelectorAll(".preset-chip").forEach((c, i) => {
    c.classList.toggle("active", i === activeIdx);
  });
}

// ── Color Sync ─────────────────────────────────────────────
function syncColorFromHex(pickerId, hexId) {
  const hex = document.getElementById(hexId).value.trim();
  if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
    document.getElementById(pickerId).value = hex;
    previewTheme();
  }
}

// ── Live Preview (header bar inside modal) ─────────────────
function previewTheme() {
  const header = document.getElementById("custColorHeader").value;
  const accent = document.getElementById("custColorAccent").value;
  // sync hex fields
  document.getElementById("custColorHeaderHex").value = header;
  document.getElementById("custColorAccentHex").value = accent;
  document.getElementById("custColorBgHex").value     = document.getElementById("custColorBg").value;
  document.getElementById("custColorBtnHex").value    = document.getElementById("custColorBtn").value;
  syncHeaderPreview();
}

function syncHeaderPreview() {
  const header  = document.getElementById("custColorHeader").value;
  const accent  = document.getElementById("custColorAccent").value;
  const appName = document.getElementById("custAppName").value || "BARAKATAK";
  const sub     = document.getElementById("custSubtitle").value || "KPI Dashboard — Program Kerja 2026";

  const prev  = document.getElementById("headerPreview");
  const badge = document.getElementById("hpBadge");
  const title = document.getElementById("hpTitle");
  const hpSub = document.getElementById("hpSub");
  const hpIcon = document.getElementById("hpIcon");
  const hpImg  = document.getElementById("hpImg");

  prev.style.background  = header;
  badge.style.background = accent;
  title.style.color      = accent;
  title.textContent      = appName.toUpperCase();
  hpSub.textContent      = sub;

  if (custState.logoType === "image" && custState.logoImage) {
    hpIcon.style.display = "none";
    hpImg.src = custState.logoImage;
    hpImg.style.display = "block";
  } else {
    hpIcon.style.display = "block";
    hpIcon.textContent   = custState.logoIcon;
    hpImg.style.display  = "none";
  }
}

// ── Apply to page ──────────────────────────────────────────
function applyCustomize() {
  // Read values
  custState.appName     = document.getElementById("custAppName").value.trim();
  custState.subtitle    = document.getElementById("custSubtitle").value.trim();
  custState.tab1        = document.getElementById("custTab1").value.trim();
  custState.tab2        = document.getElementById("custTab2").value.trim();
  custState.tab3        = document.getElementById("custTab3").value.trim();
  custState.colorHeader = document.getElementById("custColorHeader").value;
  custState.colorAccent = document.getElementById("custColorAccent").value;
  custState.colorBg     = document.getElementById("custColorBg").value;
  custState.colorBtn    = document.getElementById("custColorBtn").value;

  applyToPage(custState);
  saveCustToStorage();
  closeCustomizeModalDirect();
  showToast("🎨 Tampilan berhasil diperbarui!");
}

function applyToPage(s) {
  // ── CSS Variables ──
  const root = document.documentElement;
  root.style.setProperty("--green-dark", s.colorHeader);
  root.style.setProperty("--green-mid",  lightenColor(s.colorHeader, 15));
  root.style.setProperty("--gold",       s.colorAccent);
  root.style.setProperty("--gold-light", lightenColor(s.colorAccent, 15));
  root.style.setProperty("--cream",      s.colorBg);
  root.style.setProperty("--cream-dark", darkenColor(s.colorBg, 5));
  root.style.setProperty("--green-light",s.colorBtn);

  // ── Brand text ──
  const title = document.getElementById("brandTitle");
  const sub   = document.getElementById("brandSub");
  if (title) title.textContent = (s.appName || "BARAKATAK").toUpperCase();
  if (sub)   sub.textContent   = s.subtitle || "KPI Dashboard — Program Kerja 2026";

  // ── Tab labels ──
  const tabBtns = document.querySelectorAll(".tab-btn");
  if (tabBtns[0] && s.tab1) tabBtns[0].textContent = s.tab1;
  if (tabBtns[1] && s.tab2) tabBtns[1].textContent = s.tab2;
  if (tabBtns[2] && s.tab3) tabBtns[2].textContent = s.tab3;

  // ── Logo ──
  const brandIcon   = document.getElementById("brandIcon");
  const brandImg    = document.getElementById("brandLogoImg");
  const brandBadge  = document.getElementById("brandBadge");

  if (brandBadge) brandBadge.style.background = s.colorAccent;

  if (s.logoType === "image" && s.logoImage) {
    if (brandIcon) brandIcon.style.display = "none";
    if (brandImg)  { brandImg.src = s.logoImage; brandImg.style.display = "block"; }
  } else {
    if (brandIcon) { brandIcon.style.display = "block"; brandIcon.textContent = s.logoIcon || "◈"; }
    if (brandImg)  brandImg.style.display = "none";
  }

  // ── Page title ──
  document.title = (s.appName || "Barakatak") + " — KPI Dashboard";
}

// ── Reset ──────────────────────────────────────────────────
function resetCustomize() {
  if (!confirm("Reset semua kustomisasi ke default?")) return;
  custState = {
    appName: "", subtitle: "", tab1: "", tab2: "", tab3: "",
    logoType: "icon", logoIcon: "◈", logoImage: "",
    colorHeader: "#1A3A2A", colorAccent: "#D4A843",
    colorBg: "#F5F0E8", colorBtn: "#2D5A3D",
  };
  localStorage.removeItem("barakatak_customize");
  applyToPage(custState);
  closeCustomizeModalDirect();
  showToast("↺ Tampilan direset ke default!");
}

// ── Color Utilities ────────────────────────────────────────
function hexToRgb(hex) {
  const r = parseInt(hex.slice(1,3),16);
  const g = parseInt(hex.slice(3,5),16);
  const b = parseInt(hex.slice(5,7),16);
  return [r,g,b];
}
function rgbToHex(r,g,b) {
  return "#" + [r,g,b].map(v => Math.min(255,Math.max(0,Math.round(v))).toString(16).padStart(2,"0")).join("");
}
function lightenColor(hex, pct) {
  try {
    const [r,g,b] = hexToRgb(hex);
    return rgbToHex(r + (255-r)*pct/100, g + (255-g)*pct/100, b + (255-b)*pct/100);
  } catch { return hex; }
}
function darkenColor(hex, pct) {
  try {
    const [r,g,b] = hexToRgb(hex);
    return rgbToHex(r*(1-pct/100), g*(1-pct/100), b*(1-pct/100));
  } catch { return hex; }
}
