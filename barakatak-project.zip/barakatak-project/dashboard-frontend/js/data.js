// ============================================================
//  data.js — Default seed data untuk Barakatak KPI Dashboard
// ============================================================

const DEFAULT_DIVISIONS = [
  {
    id: "humas",
    name: "Humas",
    tagline: "Hubungan Masyarakat & Publikasi",
    icon: "📣",
    color: "#1A3A2A",    // green dark header
    kpis: [
      { id: "h1", name: "Jumlah Peserta Terdaftar", target: "150 peserta", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "h2", name: "Jangkauan Media Sosial",   target: "5.000 reach", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "h3", name: "Press Release / Publikasi", target: "3 publikasi", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "h4", name: "Koordinasi Humas Eksternal", target: "2 mitra",   realisasi: "", progress: 0, status: "planned", note: "" },
    ]
  },
  {
    id: "acara",
    name: "Acara",
    tagline: "Koordinasi & Pelaksanaan Kegiatan",
    icon: "🎪",
    color: "#7D3C98",
    kpis: [
      { id: "a1", name: "Rundown Acara Final",      target: "H-7 selesai",   realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "a2", name: "Jumlah Sesi Terlaksana",   target: "8 sesi",        realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "a3", name: "Kepuasan Peserta",          target: "≥ 80% puas",   realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "a4", name: "Ketepatan Waktu Acara",     target: "≤ 15 mnt molor", realisasi: "", progress: 0, status: "planned", note: "" },
    ]
  },
  {
    id: "mentor",
    name: "Mentor",
    tagline: "Pembinaan & Pendampingan Peserta",
    icon: "🎓",
    color: "#1A5276",
    kpis: [
      { id: "m1", name: "Jumlah Mentor Aktif",       target: "10 mentor",  realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "m2", name: "Sesi Mentoring Terlaksana",  target: "6 sesi",    realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "m3", name: "Absensi Mentee",             target: "≥ 85%",     realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "m4", name: "Evaluasi Mentoring",         target: "4.0/5.0",   realisasi: "", progress: 0, status: "planned", note: "" },
    ]
  },
  {
    id: "tatib",
    name: "Tatib",
    tagline: "Tata Tertib & Ketertiban",
    icon: "🛡️",
    color: "#784212",
    kpis: [
      { id: "t1", name: "Penyusunan Tata Tertib",   target: "H-14 selesai", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "t2", name: "Sosialisasi Tatib",         target: "100% peserta", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "t3", name: "Pelanggaran Terdata",       target: "≤ 5 kasus",  realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "t4", name: "Berita Acara Tatib",        target: "1 dokumen",   realisasi: "", progress: 0, status: "planned", note: "" },
    ]
  },
  {
    id: "logistik",
    name: "Logistik",
    tagline: "Perlengkapan & Akomodasi",
    icon: "📦",
    color: "#117A65",
    kpis: [
      { id: "l1", name: "Checklist Perlengkapan",   target: "100% siap H-1", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "l2", name: "Konsumsi Peserta",          target: "Semua sesi",    realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "l3", name: "Kendaraan / Transportasi",  target: "2 unit",        realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "l4", name: "Venue Setup Tepat Waktu",   target: "H-1 selesai",  realisasi: "", progress: 0, status: "planned", note: "" },
    ]
  },
  {
    id: "medis",
    name: "Medis",
    tagline: "Kesehatan & Keselamatan Peserta",
    icon: "🏥",
    color: "#C0392B",
    kpis: [
      { id: "md1", name: "P3K & Obat-obatan Siap",  target: "100% tersedia", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "md2", name: "Tenaga Medis On-call",     target: "1 orang/hari",  realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "md3", name: "Laporan Insiden Medis",    target: "0 insiden serius", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "md4", name: "Briefing Keselamatan",     target: "H-1 terlaksana", realisasi: "", progress: 0, status: "planned", note: "" },
    ]
  },
  {
    id: "pdd",
    name: "PDD",
    tagline: "Pubdok & Desain",
    icon: "📸",
    color: "#2C3E50",
    kpis: [
      { id: "p1", name: "Konten Pra-acara",          target: "5 postingan",   realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "p2", name: "Dokumentasi Foto & Video",  target: "Semua sesi",    realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "p3", name: "Desain Materi Cetak",        target: "Banner + Sertif", realisasi: "", progress: 0, status: "planned", note: "" },
      { id: "p4", name: "Reel / Highlight Pasca",    target: "1 reel IG",     realisasi: "", progress: 0, status: "planned", note: "" },
    ]
  },
];

const DEFAULT_BUDGET = {
  total: 5000000,  // ganti sesuai RAB aktual
};

const DEFAULT_TRANSACTIONS = [];

const DEFAULT_EVENTS = [
  { id: "ev1", name: "Rapat Kick-off Panitia",    divisi: "acara",    start: "2026-07-01", end: "2026-07-01", status: "planned",  note: "Pembentukan divisi dan pembagian tugas" },
  { id: "ev2", name: "Penyusunan Tatib & RAB",     divisi: "tatib",    start: "2026-07-05", end: "2026-07-10", status: "planned",  note: "" },
  { id: "ev3", name: "Sosialisasi Peserta",         divisi: "humas",    start: "2026-07-15", end: "2026-07-20", status: "planned",  note: "Open recruitment & informasi kegiatan" },
  { id: "ev4", name: "Koordinasi Logistik",         divisi: "logistik", start: "2026-07-25", end: "2026-07-28", status: "planned",  note: "Cek venue dan kebutuhan konsumsi" },
  { id: "ev5", name: "Hari H — BARAKATAK",          divisi: "acara",    start: "2026-08-10", end: "2026-08-12", status: "planned",  note: "Pelaksanaan utama program kerja" },
  { id: "ev6", name: "Pasca Acara & Evaluasi",      divisi: "acara",    start: "2026-08-15", end: "2026-08-17", status: "planned",  note: "LPJ dan publikasi dokumentasi" },
];

const DEFAULT_LINKS = [
  // Contoh — silakan hapus/ganti dengan link asli kamu lewat tombol "Tambah Link"
  // { id:"lk1", title:"Database Sponsor P2M 2026", url:"https://docs.google.com/spreadsheets/d/...", category:"spreadsheet", divisi:"", note:"Tracking calon sponsor & status follow-up", createdAt:new Date().toISOString() },
];
