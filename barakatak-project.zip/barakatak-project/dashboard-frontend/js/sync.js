// ============================================================
//  sync.js — Backend Sync Engine (REST API)
//  Terhubung ke backend Express milikmu sendiri (lihat folder
//  barakatak-backend/), bukan layanan pihak ketiga.
// ============================================================

// ─────────────────────────────────────────────────────────────
//  SETUP (sekali saja):
//  1. Deploy folder barakatak-backend/ ke Render.com (lihat README
//     di folder itu untuk panduan lengkap)
//  2. Salin URL backend kamu (mis. https://nama-app.onrender.com)
//  3. Isi API_BASE_URL di bawah ini
//  4. (Opsional) kalau backend pakai API_KEY, isi juga API_KEY di bawah
//  5. Re-upload folder dashboard ini ke Netlify
// ─────────────────────────────────────────────────────────────

const API_BASE_URL = "GANTI_DENGAN_URL_BACKEND_KAMU";   // ← contoh: https://barakatak-backend.onrender.com
const API_KEY       = "";                                 // ← isi kalau backend pakai API key, kalau tidak biarkan kosong

const POLL_MS          = 10000;   // cek update tiap 10 detik
const STORAGE_KEY_CUST = "barakatak_customize";

let lastUpdatedAt = "";
let pollTimer     = null;
let isSyncing     = false;

// ── Cek apakah sudah dikonfigurasi ─────────────────────────
function checkConfig() {
  return (
    API_BASE_URL &&
    API_BASE_URL !== "GANTI_DENGAN_URL_BACKEND_KAMU" &&
    /^https?:\/\//.test(API_BASE_URL)
  );
}

function buildHeaders(extra = {}) {
  const headers = { "Content-Type": "application/json", ...extra };
  if (API_KEY) headers["X-Api-Key"] = API_KEY;
  return headers;
}

// ── PULL dari backend ───────────────────────────────────────
async function pullData() {
  if (!checkConfig()) {
    setSyncStatus("local");
    loadFromLocalStorage();
    renderAll();
    populateSelects();
    updateTimestamp();
    return;
  }

  setSyncStatus("syncing");
  try {
    const res = await fetch(`${API_BASE_URL}/api/data`, {
      method: "GET",
      headers: buildHeaders(),
    });
    if (!res.ok) throw new Error("HTTP " + res.status);

    const data = await res.json();

    if (data.updatedAt !== lastUpdatedAt) {
      lastUpdatedAt = data.updatedAt || "";
      divisions    = data.divisions    || JSON.parse(JSON.stringify(DEFAULT_DIVISIONS));
      transactions = data.transactions || [];
      events       = data.events       || DEFAULT_EVENTS.map(e => ({...e}));
      totalBudget  = data.totalBudget  || DEFAULT_BUDGET.total;
      dashLinks    = data.dashLinks    || [];
      renderAll();
      populateSelects();
    }

    setSyncStatus("ok");
    localStorage.setItem("barakatak_backup", JSON.stringify({ divisions, transactions, events, totalBudget, dashLinks }));
  } catch (err) {
    console.warn("Backend pull error:", err);
    setSyncStatus("error");
    loadFromLocalStorage();
    renderAll();
    populateSelects();
  }
  updateTimestamp();
}

// ── PUSH ke backend ────────────────────────────────────────
async function pushData(silent = false) {
  if (!checkConfig()) {
    const payload = { divisions, transactions, events, totalBudget, dashLinks };
    localStorage.setItem("barakatak_backup", JSON.stringify(payload));
    setSyncStatus("local");
    updateTimestamp();
    if (!silent) showToast("💾 Tersimpan lokal (backend belum dikonfigurasi)");
    return;
  }

  setSyncStatus("syncing");
  try {
    const payload = { divisions, transactions, events, totalBudget, dashLinks };
    const res = await fetch(`${API_BASE_URL}/api/data`, {
      method: "PUT",
      headers: buildHeaders(),
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error("HTTP " + res.status);

    const json = await res.json();
    lastUpdatedAt = json.updatedAt || "";

    localStorage.setItem("barakatak_backup", JSON.stringify(payload));
    setSyncStatus("ok");
    updateTimestamp();
    if (!silent) showToast("☁️ Tersimpan & tersinkron ke semua device!");
  } catch (err) {
    console.warn("Backend push error:", err);
    localStorage.setItem("barakatak_backup", JSON.stringify({ divisions, transactions, events, totalBudget, dashLinks }));
    setSyncStatus("error");
    updateTimestamp();
    if (!silent) showToast("⚠️ Sync gagal (cek koneksi/backend), tersimpan lokal");
  }
}

// ── Polling otomatis ───────────────────────────────────────
function startPolling() {
  clearInterval(pollTimer);
  if (!checkConfig()) return;
  pollTimer = setInterval(async () => {
    if (!isSyncing) {
      isSyncing = true;
      await pullData();
      isSyncing = false;
    }
  }, POLL_MS);
}

// ── Fallback: baca dari localStorage ──────────────────────
function loadFromLocalStorage() {
  try {
    const raw = localStorage.getItem("barakatak_backup");
    if (raw) {
      const p = JSON.parse(raw);
      divisions    = p.divisions    || JSON.parse(JSON.stringify(DEFAULT_DIVISIONS));
      transactions = p.transactions || [];
      events       = p.events       || DEFAULT_EVENTS.map(e => ({...e}));
      totalBudget  = p.totalBudget  || DEFAULT_BUDGET.total;
      dashLinks    = p.dashLinks    || DEFAULT_LINKS.map(l => ({...l}));
    } else {
      divisions    = JSON.parse(JSON.stringify(DEFAULT_DIVISIONS));
      transactions = [];
      events       = DEFAULT_EVENTS.map(e => ({...e}));
      totalBudget  = DEFAULT_BUDGET.total;
      dashLinks    = DEFAULT_LINKS.map(l => ({...l}));
    }
  } catch(e) {
    divisions    = JSON.parse(JSON.stringify(DEFAULT_DIVISIONS));
    transactions = [];
    events       = DEFAULT_EVENTS.map(e => ({...e}));
    totalBudget  = DEFAULT_BUDGET.total;
    dashLinks    = DEFAULT_LINKS.map(l => ({...l}));
  }
}

// ── Customize: tetap localStorage (per-user, bukan shared) ──
function applyStoredCustomize() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CUST);
    if (raw && typeof applyToPage === "function") applyToPage(JSON.parse(raw));
  } catch(e) {}
}

// ── Status indicator ──────────────────────────────────────
function setSyncStatus(state) {
  const dot   = document.getElementById("syncDot");
  const label = document.getElementById("syncLabel");
  if (!dot || !label) return;
  const map = {
    syncing: { cls: "sync-syncing", txt: "Menyinkron…" },
    ok:      { cls: "sync-ok",      txt: "Tersinkron ☁️" },
    error:   { cls: "sync-error",   txt: "Backend Offline ⚠️" },
    local:   { cls: "sync-local",   txt: "Mode Lokal 💾" },
  };
  const s = map[state] || map.local;
  dot.className     = "sync-dot " + s.cls;
  label.textContent = s.txt;
}

function updateTimestamp() {
  const el = document.getElementById("lastUpdated");
  if (el) el.textContent = new Date().toLocaleString("id-ID");
}

// ── Tampilkan setup banner jika belum dikonfigurasi ───────
document.addEventListener("DOMContentLoaded", () => {
  if (!checkConfig()) {
    const banner = document.getElementById("setupBanner");
    if (banner) banner.classList.remove("hidden");
  }
});
