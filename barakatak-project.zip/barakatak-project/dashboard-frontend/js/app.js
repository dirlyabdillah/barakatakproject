// ============================================================
//  app.js — Barakatak KPI Dashboard
//  Sync engine ada di js/sync.js (JSONBin.io)
// ============================================================

// ── STATE ──────────────────────────────────────────────────
let divisions       = [];
let transactions    = [];
let events          = [];
let totalBudget     = DEFAULT_BUDGET.total;
let editMeta        = null;
let activeRiskDivId = null;
let pendingBuktiB64 = null;
let newDivSelectedEmoji = "📋";
let dashLinks        = [];
let activeLinkId      = null;
let activeLinkFilter  = "";

// ── INIT ───────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  initTabs();
  buildNewDivEmojiGrid();
  await pullData();      // dari sync.js
  startPolling();        // dari sync.js
  populateSelects();
  setDateDefaults();
  applyStoredCustomize(); // dari sync.js
});

// ── TABS ───────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach(p => p.classList.add("hidden"));
      btn.classList.add("active");
      document.getElementById("tab-" + btn.dataset.tab).classList.remove("hidden");
      if (btn.dataset.tab === "keuangan") { renderBudgetSummary(); renderTransactions(); }
      if (btn.dataset.tab === "timeline") { renderEvents(); renderTimeline(); }
      if (btn.dataset.tab === "links")    { renderLinks(); }
    });
  });
}

// ── RENDER ALL ─────────────────────────────────────────────
function renderAll() {
  renderDivisions();
  renderBudgetSummary();
  renderTransactions();
  renderEvents();
  renderTimeline();
  renderLinks();
  updateOverview();
}

// ── DIVISIONS ──────────────────────────────────────────────
function renderDivisions() {
  const grid = document.getElementById("divisionsGrid");
  grid.innerHTML = "";
  divisions.forEach(div => grid.appendChild(buildDivCard(div)));
}

function buildDivCard(div) {
  const totalKpis   = div.kpis.length;
  const avgProgress = totalKpis ? Math.round(div.kpis.reduce((s,k) => s + k.progress, 0) / totalKpis) : 0;
  const risks       = div.risks || [];
  const openRisks   = risks.filter(r => r.status === "open" || r.status === "mitigated").length;
  const highRisks   = risks.filter(r => r.level === "high" && r.status === "open").length;

  const r = 22, circ = 2 * Math.PI * r;
  const offset = circ - (avgProgress / 100) * circ;
  const ringColor = avgProgress >= 75 ? "#4A8C60" : avgProgress >= 40 ? "#D4A843" : "#E74C3C";

  const card = document.createElement("div");
  card.className = "div-card";
  card.id = "divcard-" + div.id;

  // Header
  const hdr = document.createElement("div");
  hdr.className = "div-card-header";
  hdr.style.background = div.color;
  hdr.innerHTML = `
    <div class="div-icon" style="background:rgba(255,255,255,.15)">${div.icon}</div>
    <div class="div-info">
      <div class="div-name">${div.name}</div>
      <div class="div-tagline">${div.tagline}</div>
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px">
      <div class="div-ring-wrap">
        <svg class="ring-svg" width="56" height="56" viewBox="0 0 56 56">
          <circle class="ring-bg" cx="28" cy="28" r="${r}"/>
          <circle class="ring-fg" cx="28" cy="28" r="${r}"
            stroke="${ringColor}" stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${offset.toFixed(1)}"/>
          <g transform="rotate(90,28,28)">
            <text class="ring-pct" x="28" y="28">${avgProgress}%</text>
          </g>
        </svg>
      </div>
      <button class="btn-del-div" onclick="deleteDivisi('${div.id}')" title="Hapus Divisi">🗑️</button>
    </div>`;
  card.appendChild(hdr);

  // KPI List
  const kpiList = document.createElement("div");
  kpiList.className = "div-kpi-list";
  div.kpis.forEach(kpi => {
    const item = document.createElement("div");
    item.className = "kpi-item";
    item.onclick = () => openKpiModal(div.id, kpi.id);
    const statusColor = { planned:"#BDC3C7", ongoing:"#D4A843", done:"#4A8C60", blocked:"#E74C3C" }[kpi.status] || "#ccc";
    item.innerHTML = `
      <div class="kpi-status-dot" style="background:${statusColor}"></div>
      <div style="flex:1;min-width:0">
        <div class="kpi-label">${kpi.name}</div>
        <div class="kpi-target-txt">Target: ${kpi.target}${kpi.realisasi ? ' · Real: '+kpi.realisasi : ''}</div>
        ${kpi.note ? `<div class="kpi-note">${kpi.note}</div>` : ""}
      </div>
      <div class="kpi-bar-wrap"><div class="kpi-bar"><div class="kpi-bar-fill bar-${kpi.status}" style="width:${kpi.progress}%"></div></div></div>
      <div class="kpi-pct">${kpi.progress}%</div>`;
    kpiList.appendChild(item);
  });
  card.appendChild(kpiList);

  // Add KPI btn
  const addKpiBtn = document.createElement("button");
  addKpiBtn.className = "div-add-kpi";
  addKpiBtn.textContent = "+ Tambah KPI";
  addKpiBtn.onclick = () => addNewKpi(div.id);
  card.appendChild(addKpiBtn);

  // Risk Management Section
  const riskSection = document.createElement("div");
  riskSection.className = "risk-section";
  riskSection.innerHTML = `
    <div class="risk-section-header" onclick="openRiskModal('${div.id}')">
      <div class="risk-section-title">
        🛡️ Risk Management
        ${openRisks > 0 ? `<span class="risk-badge ${highRisks>0?'risk-badge-high':''}">${openRisks} aktif${highRisks>0?' · '+highRisks+' tinggi':''}</span>` : '<span class="risk-badge-none">Aman</span>'}
      </div>
      <span class="risk-chevron">›</span>
    </div>
    ${risks.length > 0 ? `<div class="risk-preview">${risks.slice(0,2).map(r=>`
      <div class="risk-preview-item">
        <span class="risk-dot-${r.level}"></span>
        <span class="risk-preview-text">${r.desc}</span>
        <span class="risk-status-mini risk-status-${r.status}">${{open:'Terbuka',mitigated:'Dimitigasi',closed:'Selesai'}[r.status]}</span>
      </div>`).join("")}
      ${risks.length > 2 ? `<div style="font-size:11px;color:#888;padding:4px 8px">+${risks.length-2} risiko lainnya…</div>` : ''}
    </div>` : ''}`;
  card.appendChild(riskSection);

  return card;
}

// ── ADD DIVISI ─────────────────────────────────────────────
const DIV_EMOJIS = ["📋","📌","🎯","⚡","🏆","🔥","💡","🌟","🚀","⚙️","🛡️","📊","💼","🎓","🌿","🎪","📣","💰","📸","🔷","🦅","🏥","📦","🎨","🤝"];

function buildNewDivEmojiGrid() {
  const grid = document.getElementById("newDivEmojiGrid");
  if (!grid) return;
  grid.innerHTML = DIV_EMOJIS.map(e => `
    <div class="emoji-opt${e===newDivSelectedEmoji?' selected':''}" onclick="selectNewDivEmoji('${e}')">${e}</div>
  `).join("");
}

function selectNewDivEmoji(e) {
  newDivSelectedEmoji = e;
  document.getElementById("newDivEmojiSelected").textContent = e;
  buildNewDivEmojiGrid();
}

function syncColorFromHexSimple(pickerId, hexId) {
  const hex = document.getElementById(hexId).value.trim();
  if (/^#[0-9A-Fa-f]{6}$/.test(hex)) document.getElementById(pickerId).value = hex;
}

function openAddDivisiModal() {
  newDivSelectedEmoji = "📋";
  document.getElementById("newDivName").value    = "";
  document.getElementById("newDivTagline").value = "";
  document.getElementById("newDivColor").value   = "#2C3E50";
  document.getElementById("newDivColorHex").value= "#2C3E50";
  document.getElementById("newDivEmojiSelected").textContent = "📋";
  buildNewDivEmojiGrid();
  document.getElementById("addDivisiModal").classList.remove("hidden");
}
function closeAddDivisiModal() { document.getElementById("addDivisiModal").classList.add("hidden"); }

async function confirmAddDivisi() {
  const name    = document.getElementById("newDivName").value.trim();
  const tagline = document.getElementById("newDivTagline").value.trim();
  const color   = document.getElementById("newDivColor").value;
  if (!name) { showToast("⚠️ Nama divisi wajib diisi!"); return; }

  const id = "div_" + Date.now();
  divisions.push({ id, name, tagline: tagline||name, icon: newDivSelectedEmoji, color, kpis: [], risks: [] });
  closeAddDivisiModal();
  renderDivisions();
  populateSelects();
  updateOverview();
  await pushData();
  showToast(`✅ Divisi "${name}" berhasil ditambahkan!`);
}

async function deleteDivisi(divId) {
  const div = divisions.find(d => d.id === divId);
  if (!div) return;
  if (!confirm(`Hapus divisi "${div.name}"?\n\nSemua KPI, risiko, dan data terkait akan ikut dihapus.`)) return;

  divisions    = divisions.filter(d => d.id !== divId);
  transactions = transactions.map(t => t.divisi === divId ? {...t, divisi: ""} : t); // unlink, jangan hapus
  events       = events.map(e => e.divisi === divId ? {...e, divisi: ""} : e);

  renderDivisions();
  renderBudgetSummary();
  renderTransactions();
  renderEvents();
  renderTimeline();
  populateSelects();
  updateOverview();
  await pushData();
  showToast(`🗑️ Divisi "${div.name}" dihapus.`);
}

// ── KPI ────────────────────────────────────────────────────
function openKpiModal(divId, kpiId) {
  const div = divisions.find(d => d.id === divId);
  const kpi = div.kpis.find(k => k.id === kpiId);
  editMeta = { divId, kpiId };
  document.getElementById("modalTitle").textContent = `Edit KPI — ${div.name}`;
  document.getElementById("mKpiName").value     = kpi.name;
  document.getElementById("mKpiTarget").value   = kpi.target;
  document.getElementById("mKpiReal").value     = kpi.realisasi || "";
  document.getElementById("mKpiProgress").value = kpi.progress;
  document.getElementById("mKpiProgressVal").textContent = kpi.progress + "%";
  document.getElementById("mKpiStatus").value   = kpi.status;
  document.getElementById("mKpiNote").value     = kpi.note || "";
  document.getElementById("kpiModal").classList.remove("hidden");
}
function closeModalDirect() { document.getElementById("kpiModal").classList.add("hidden"); editMeta = null; }

async function saveKpiEdit() {
  if (!editMeta) return;
  const div = divisions.find(d => d.id === editMeta.divId);
  const kpi = div.kpis.find(k => k.id === editMeta.kpiId);
  kpi.name      = document.getElementById("mKpiName").value.trim() || kpi.name;
  kpi.target    = document.getElementById("mKpiTarget").value.trim();
  kpi.realisasi = document.getElementById("mKpiReal").value.trim();
  kpi.progress  = Number(document.getElementById("mKpiProgress").value);
  kpi.status    = document.getElementById("mKpiStatus").value;
  kpi.note      = document.getElementById("mKpiNote").value.trim();
  closeModalDirect();
  renderDivisions();
  updateOverview();
  await pushData();
  showToast("✅ KPI diperbarui!");
}

async function deleteCurrentKpi() {
  if (!editMeta) return;
  const div = divisions.find(d => d.id === editMeta.divId);
  const kpi = div.kpis.find(k => k.id === editMeta.kpiId);
  if (!confirm(`Hapus KPI "${kpi.name}"?`)) return;
  div.kpis = div.kpis.filter(k => k.id !== editMeta.kpiId);
  closeModalDirect();
  renderDivisions();
  updateOverview();
  await pushData();
  showToast("🗑️ KPI dihapus.");
}

function addNewKpi(divId) {
  const div = divisions.find(d => d.id === divId);
  const newId = divId + "_kpi" + Date.now();
  div.kpis.push({ id: newId, name: "KPI Baru", target: "—", realisasi: "", progress: 0, status: "planned", note: "" });
  renderDivisions();
  openKpiModal(divId, newId);
}

// ── RISK MANAGEMENT ────────────────────────────────────────
function openRiskModal(divId) {
  activeRiskDivId = divId;
  const div = divisions.find(d => d.id === divId);
  document.getElementById("riskModalTitle").textContent = `🛡️ Risk Management — ${div.icon} ${div.name}`;
  document.getElementById("rNewDesc").value     = "";
  document.getElementById("rNewMitigasi").value = "";
  document.getElementById("rNewLevel").value    = "medium";
  document.getElementById("rNewStatus").value   = "open";
  renderRiskTable();
  document.getElementById("riskModal").classList.remove("hidden");
}
function closeRiskModal() { document.getElementById("riskModal").classList.add("hidden"); activeRiskDivId = null; }

function renderRiskTable() {
  const div   = divisions.find(d => d.id === activeRiskDivId);
  const risks = div.risks || [];
  const tbody = document.getElementById("riskBody");
  if (!risks.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-state">Belum ada risiko tercatat.</td></tr>`;
    return;
  }
  const levelLabel  = { low:"🟢 Rendah", medium:"🟡 Sedang", high:"🔴 Tinggi" };
  const statusLabel = { open:"Terbuka", mitigated:"Dimitigasi", closed:"Selesai" };
  tbody.innerHTML = risks.map((r, i) => `
    <tr>
      <td style="color:#888;font-size:12px">${i+1}</td>
      <td style="font-weight:600">${r.desc}</td>
      <td>${levelLabel[r.level]||r.level}</td>
      <td style="font-size:12px;color:#555">${r.mitigasi||"—"}</td>
      <td>
        <select class="form-input-sm" onchange="updateRiskStatus('${r.id}',this.value)">
          ${["open","mitigated","closed"].map(s=>`<option value="${s}"${r.status===s?" selected":""}>${statusLabel[s]}</option>`).join("")}
        </select>
      </td>
      <td><button class="btn-icon btn-danger" onclick="deleteRisk('${r.id}')">🗑️</button></td>
    </tr>`).join("");
}

async function addRisk() {
  const desc     = document.getElementById("rNewDesc").value.trim();
  const level    = document.getElementById("rNewLevel").value;
  const mitigasi = document.getElementById("rNewMitigasi").value.trim();
  const status   = document.getElementById("rNewStatus").value;
  if (!desc) { showToast("⚠️ Deskripsi risiko wajib diisi!"); return; }
  const div = divisions.find(d => d.id === activeRiskDivId);
  if (!div.risks) div.risks = [];
  div.risks.push({ id: "r" + Date.now(), desc, level, mitigasi, status });
  document.getElementById("rNewDesc").value     = "";
  document.getElementById("rNewMitigasi").value = "";
  renderRiskTable();
  renderDivisions();
  updateOverview();
  await pushData();
  showToast("✅ Risiko ditambahkan!");
}

async function updateRiskStatus(rId, val) {
  const div = divisions.find(d => d.id === activeRiskDivId);
  const risk = (div.risks||[]).find(r => r.id === rId);
  if (risk) { risk.status = val; }
  renderRiskTable();
  renderDivisions();
  updateOverview();
  await pushData();
}

async function deleteRisk(rId) {
  if (!confirm("Hapus risiko ini?")) return;
  const div = divisions.find(d => d.id === activeRiskDivId);
  div.risks = (div.risks||[]).filter(r => r.id !== rId);
  renderRiskTable();
  renderDivisions();
  updateOverview();
  await pushData();
  showToast("🗑️ Risiko dihapus.");
}

// ── OVERVIEW ───────────────────────────────────────────────
function updateOverview() {
  let totalKpi = 0, doneKpi = 0, totalProg = 0, activeRisks = 0;
  divisions.forEach(div => {
    div.kpis.forEach(kpi => {
      totalKpi++; totalProg += kpi.progress;
      if (kpi.status === "done") doneKpi++;
    });
    (div.risks||[]).forEach(r => { if (r.status !== "closed") activeRisks++; });
  });
  const overall = totalKpi ? Math.round(totalProg / totalKpi) : 0;
  const totalOut = transactions.filter(t => t.type === "out").reduce((s,t) => s + t.amount, 0);
  const budgetPct = totalBudget ? Math.round((totalOut / totalBudget) * 100) : 0;
  document.getElementById("ov-overall").querySelector(".ov-num").textContent = overall + "%";
  document.getElementById("ov-done").querySelector(".ov-num").textContent    = doneKpi;
  document.getElementById("ov-total").querySelector(".ov-num").textContent   = totalKpi;
  document.getElementById("ov-risk").querySelector(".ov-num").textContent    = activeRisks;
  document.getElementById("ov-budget").querySelector(".ov-num").textContent  = budgetPct + "%";
}

// ── KEUANGAN ───────────────────────────────────────────────
function renderBudgetSummary() {
  const container = document.getElementById("budgetSummary");
  const totalIn   = transactions.filter(t => t.type === "in").reduce((s,t) => s + t.amount, 0);
  const totalOut  = transactions.filter(t => t.type === "out").reduce((s,t) => s + t.amount, 0);
  const saldo     = totalIn - totalOut;
  const budgetPct = totalBudget ? Math.min(100, Math.round((totalOut / totalBudget) * 100)) : 0;

  const perDivisi = divisions.map(div => {
    const dOut = transactions.filter(t => t.type==="out" && t.divisi===div.id).reduce((s,t)=>s+t.amount,0);
    const dIn  = transactions.filter(t => t.type==="in"  && t.divisi===div.id).reduce((s,t)=>s+t.amount,0);
    return `<div class="budget-card"><div class="budget-card-label">${div.icon} ${div.name}</div>
      <div style="font-size:12px;color:#888;margin-top:4px">
        <span style="color:#1E8449">▲ ${formatRp(dIn)}</span> &nbsp; <span style="color:#c0392b">▼ ${formatRp(dOut)}</span>
      </div></div>`;
  }).join("");

  container.innerHTML = `
    <div class="budget-card">
      <div class="budget-card-label">Total Anggaran</div>
      <div class="budget-card-val val-blue">${formatRp(totalBudget)}</div>
      <button class="btn-icon" onclick="changeBudget()" style="margin-top:8px">✏️ Edit</button>
    </div>
    <div class="budget-card"><div class="budget-card-label">Total Pemasukan</div><div class="budget-card-val val-green">${formatRp(totalIn)}</div></div>
    <div class="budget-card">
      <div class="budget-card-label">Total Pengeluaran</div>
      <div class="budget-card-val val-red">${formatRp(totalOut)}</div>
      <div class="budget-bar"><div class="budget-bar-fill" style="width:${budgetPct}%;background:${budgetPct>85?'#e74c3c':'#4A8C60'}"></div></div>
      <div style="font-size:10px;color:#888;margin-top:3px">${budgetPct}% dari anggaran</div>
    </div>
    <div class="budget-card"><div class="budget-card-label">Saldo</div><div class="budget-card-val ${saldo>=0?'val-green':'val-red'}">${formatRp(saldo)}</div></div>
    ${perDivisi}`;
}

async function changeBudget() {
  const val = prompt("Total anggaran (angka saja):", totalBudget);
  if (val && !isNaN(Number(val))) {
    totalBudget = Number(val);
    renderBudgetSummary();
    updateOverview();
    await pushData();
    showToast("✅ Anggaran diperbarui!");
  }
}

function populateSelects() {
  ["txDivisi","evDivisi"].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    const cur = el.value;
    el.innerHTML = `<option value="">— Pilih Divisi —</option>`;
    divisions.forEach(div => {
      const o = document.createElement("option");
      o.value = div.id; o.textContent = div.icon + " " + div.name;
      el.appendChild(o);
    });
    if (cur) el.value = cur;
  });
  const fEl = document.getElementById("filterDivisi");
  if (fEl) {
    const cur = fEl.value;
    fEl.innerHTML = `<option value="">Semua Divisi</option>`;
    divisions.forEach(div => {
      const o = document.createElement("option");
      o.value = div.id; o.textContent = div.icon + " " + div.name;
      fEl.appendChild(o);
    });
    if (cur) fEl.value = cur;
  }
}

// ── BUKTI TRANSAKSI ────────────────────────────────────────
function previewBukti(e) {
  const file = e.target.files[0];
  if (!file) return;
  if (file.size > 3 * 1024 * 1024) { showToast("⚠️ File terlalu besar! Maks 3MB."); return; }
  const reader = new FileReader();
  reader.onload = ev => {
    pendingBuktiB64 = ev.target.result;
    const prev = document.getElementById("txBuktiPreview");
    prev.classList.remove("hidden");
    if (file.type.startsWith("image/")) {
      prev.innerHTML = `<img src="${pendingBuktiB64}" style="max-height:60px;border-radius:5px;border:1px solid #ddd" />`;
    } else {
      prev.innerHTML = `<span style="font-size:24px">📄</span><span style="font-size:11px">${file.name}</span>`;
    }
  };
  reader.readAsDataURL(file);
}

async function addTransaction() {
  const date   = document.getElementById("txDate").value;
  const type   = document.getElementById("txType").value;
  const divisi = document.getElementById("txDivisi").value;
  const kat    = document.getElementById("txKategori").value.trim();
  const ket    = document.getElementById("txKet").value.trim();
  const amount = Number(document.getElementById("txAmount").value);
  if (!date || !ket || !amount) { showToast("⚠️ Lengkapi tanggal, keterangan, dan jumlah!"); return; }

  transactions.push({ id:"tx"+Date.now(), date, type, divisi, kategori:kat, ket, amount, bukti: pendingBuktiB64||"" });
  ["txKategori","txKet","txAmount"].forEach(id => document.getElementById(id).value = "");
  document.getElementById("txBuktiPreview").innerHTML = "";
  document.getElementById("txBuktiPreview").classList.add("hidden");
  document.getElementById("txBukti").value = "";
  pendingBuktiB64 = null;

  renderBudgetSummary();
  renderTransactions();
  updateOverview();
  await pushData();
  showToast("✅ Transaksi ditambahkan!");
}

async function deleteTransaction(id) {
  if (!confirm("Hapus transaksi ini?")) return;
  transactions = transactions.filter(t => t.id !== id);
  renderBudgetSummary();
  renderTransactions();
  updateOverview();
  await pushData();
  showToast("🗑️ Transaksi dihapus.");
}

function renderTransactions() {
  const tbody = document.getElementById("txBody");
  const foot  = document.getElementById("txFooter");
  if (!tbody) return;
  const fDiv  = document.getElementById("filterDivisi")?.value || "";
  const fType = document.getElementById("filterType")?.value   || "";

  let rows = [...transactions].sort((a,b) => b.date.localeCompare(a.date));
  if (fDiv)  rows = rows.filter(t => t.divisi === fDiv);
  if (fType) rows = rows.filter(t => t.type   === fType);

  const divMap = Object.fromEntries(divisions.map(d => [d.id, d.icon+" "+d.name]));

  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="empty-state">Belum ada transaksi.</td></tr>`;
    if (foot) foot.innerHTML = "";
    return;
  }

  tbody.innerHTML = rows.map(t => `
    <tr>
      <td>${t.date}</td>
      <td><span class="badge badge-${t.type}">${t.type==="in"?"Pemasukan":"Pengeluaran"}</span></td>
      <td>${divMap[t.divisi]||t.divisi||"—"}</td>
      <td>${t.kategori||"—"}</td>
      <td>${t.ket}</td>
      <td style="font-weight:700;color:${t.type==="in"?"#1E8449":"#c0392b"}">${formatRp(t.amount)}</td>
      <td>${t.bukti
        ? `<button class="btn-bukti" onclick="showBukti('${t.id}')">🖼️ Lihat</button>`
        : `<span style="color:#bbb;font-size:11px">—</span>`}</td>
      <td><button class="btn-icon btn-danger" onclick="deleteTransaction('${t.id}')">🗑️</button></td>
    </tr>`).join("");

  const sumIn  = rows.filter(t=>t.type==="in").reduce((s,t)=>s+t.amount,0);
  const sumOut = rows.filter(t=>t.type==="out").reduce((s,t)=>s+t.amount,0);
  if (foot) foot.innerHTML = `${rows.length} transaksi &nbsp;|&nbsp; Masuk: <strong style="color:#1E8449">${formatRp(sumIn)}</strong> &nbsp;|&nbsp; Keluar: <strong style="color:#c0392b">${formatRp(sumOut)}</strong>`;
}

function showBukti(txId) {
  const tx = transactions.find(t => t.id === txId);
  if (!tx || !tx.bukti) return;
  const imgEl  = document.getElementById("buktiModalImg");
  const pdfEl  = document.getElementById("buktiModalPdf");
  const pdfLnk = document.getElementById("buktiModalPdfLink");
  if (tx.bukti.startsWith("data:image")) {
    imgEl.src = tx.bukti; imgEl.style.display = "block"; pdfEl.style.display = "none";
  } else {
    imgEl.style.display = "none"; pdfEl.style.display = "block";
    pdfLnk.href = tx.bukti;
  }
  document.getElementById("buktiModal").classList.remove("hidden");
}
function closeBuktiModal() { document.getElementById("buktiModal").classList.add("hidden"); }

// ── TIMELINE ───────────────────────────────────────────────
function setDateDefaults() {
  const today = new Date().toISOString().split("T")[0];
  ["txDate","evStart","evEnd"].forEach(id => { const el=document.getElementById(id); if(el&&!el.value) el.value=today; });
}

async function addEvent() {
  const name   = document.getElementById("evName").value.trim();
  const divisi = document.getElementById("evDivisi").value;
  const start  = document.getElementById("evStart").value;
  const end    = document.getElementById("evEnd").value;
  const status = document.getElementById("evStatus").value;
  const note   = document.getElementById("evNote").value.trim();
  if (!name||!start||!end) { showToast("⚠️ Lengkapi nama, tanggal mulai & selesai!"); return; }
  if (end<start) { showToast("⚠️ Tanggal selesai tidak boleh sebelum mulai!"); return; }
  events.push({ id:"ev"+Date.now(), name, divisi, start, end, status, note });
  document.getElementById("evName").value = ""; document.getElementById("evNote").value = "";
  renderEvents(); renderTimeline();
  await pushData();
  showToast("✅ Kegiatan ditambahkan!");
}

async function deleteEvent(id) {
  if (!confirm("Hapus kegiatan ini?")) return;
  events = events.filter(e => e.id !== id);
  renderEvents(); renderTimeline();
  await pushData();
  showToast("🗑️ Kegiatan dihapus.");
}

async function updateEventStatus(id, val) {
  const ev = events.find(e => e.id === id);
  if (ev) { ev.status = val; renderTimeline(); await pushData(); }
}

function renderEvents() {
  const tbody = document.getElementById("evBody");
  if (!tbody) return;
  const divMap = Object.fromEntries(divisions.map(d => [d.id, d.icon+" "+d.name]));
  const sorted = [...events].sort((a,b) => a.start.localeCompare(b.start));
  if (!sorted.length) { tbody.innerHTML=`<tr><td colspan="7" class="empty-state">Belum ada kegiatan.</td></tr>`; return; }
  const statusLabel = { planned:"Direncanakan", ongoing:"Sedang Berjalan", done:"Selesai", cancelled:"Dibatalkan" };
  tbody.innerHTML = sorted.map(ev=>`
    <tr>
      <td style="font-weight:600">${ev.name}</td>
      <td>${divMap[ev.divisi]||ev.divisi||"—"}</td>
      <td>${formatDateID(ev.start)}</td><td>${formatDateID(ev.end)}</td>
      <td><select class="form-input-sm" onchange="updateEventStatus('${ev.id}',this.value)">
        ${["planned","ongoing","done","cancelled"].map(s=>`<option value="${s}"${ev.status===s?" selected":""}>${statusLabel[s]}</option>`).join("")}
      </select></td>
      <td style="color:#888;font-size:12px">${ev.note||"—"}</td>
      <td><button class="btn-icon btn-danger" onclick="deleteEvent('${ev.id}')">🗑️</button></td>
    </tr>`).join("");
}

function renderTimeline() {
  const container = document.getElementById("timelineViz");
  if (!container) return;
  if (!events.length) { container.innerHTML=`<div class="empty-state"><div class="empty-icon">📅</div>Belum ada kegiatan.</div>`; return; }
  const sorted = [...events].sort((a,b) => a.start.localeCompare(b.start));
  const startMonth = new Date(new Date(sorted[0].start).getFullYear(), new Date(sorted[0].start).getMonth(), 1);
  const endMonth   = new Date(new Date(sorted[sorted.length-1].end).getFullYear(), new Date(sorted[sorted.length-1].end).getMonth()+1, 0);
  const totalDays  = Math.max(1, daysBetween(startMonth, endMonth));
  const months = []; let cur = new Date(startMonth);
  while (cur <= endMonth) { months.push(new Date(cur)); cur.setMonth(cur.getMonth()+1); }
  const mNames = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
  const divMap = Object.fromEntries(divisions.map(d => [d.id, d]));
  let html = `<div class="tl-gantt"><div class="tl-header"><div class="tl-row-label">Kegiatan</div><div class="tl-months">${months.map(m=>`<div class="tl-month">${mNames[m.getMonth()]} '${String(m.getFullYear()).slice(2)}</div>`).join("")}</div></div>`;
  sorted.forEach(ev => {
    const evS = new Date(ev.start), evE = new Date(ev.end);
    const lp  = (daysBetween(startMonth,evS)/totalDays*100).toFixed(2);
    const wp  = Math.max(0.5,(daysBetween(evS,evE)+1)/totalDays*100).toFixed(2);
    const div = divMap[ev.divisi];
    const col = div ? div.color : "#2C3E50";
    html += `<div class="tl-event-row"><div class="tl-event-label" title="${ev.name}">${div?div.icon:""} ${ev.name}</div>
      <div class="tl-track"><div class="tl-bar ${ev.status}" style="left:${lp}%;width:${wp}%;background:${col};opacity:${ev.status==='cancelled'?.4:1}" title="${ev.name}: ${ev.start} → ${ev.end}">${wp>6?ev.name:""}</div></div></div>`;
  });
  html += `</div>`;
  container.innerHTML = html;
}

// ── DASHBOARD LINK ─────────────────────────────────────────
const LINK_CAT_LABEL = { spreadsheet:"📊 Spreadsheet", dokumen:"📄 Dokumen", drive:"📁 Drive", form:"📝 Form", lainnya:"🔗 Lainnya" };
const LINK_CAT_COLOR = { spreadsheet:"#1E8449", dokumen:"#2980B9", drive:"#D4A843", form:"#8E44AD", lainnya:"#7F8C8D" };

function openAddLinkModal() {
  activeLinkId = null;
  document.getElementById("linkModalTitle").textContent = "➕ Tambah Link";
  document.getElementById("lkTitle").value    = "";
  document.getElementById("lkUrl").value      = "";
  document.getElementById("lkCategory").value = "spreadsheet";
  document.getElementById("lkNote").value     = "";
  populateLinkDivisiSelect();
  document.getElementById("lkDivisi").value   = "";
  document.getElementById("lkDeleteBtn").classList.add("hidden");
  document.getElementById("linkModal").classList.remove("hidden");
}

function openEditLinkModal(linkId) {
  const link = dashLinks.find(l => l.id === linkId);
  if (!link) return;
  activeLinkId = linkId;
  document.getElementById("linkModalTitle").textContent = "✏️ Edit Link";
  document.getElementById("lkTitle").value    = link.title;
  document.getElementById("lkUrl").value      = link.url;
  document.getElementById("lkCategory").value = link.category;
  document.getElementById("lkNote").value     = link.note || "";
  populateLinkDivisiSelect();
  document.getElementById("lkDivisi").value   = link.divisi || "";
  document.getElementById("lkDeleteBtn").classList.remove("hidden");
  document.getElementById("linkModal").classList.remove("hidden");
}

function closeLinkModal() {
  document.getElementById("linkModal").classList.add("hidden");
  activeLinkId = null;
}

function populateLinkDivisiSelect() {
  const el = document.getElementById("lkDivisi");
  el.innerHTML = `<option value="">— Tidak terkait divisi —</option>`;
  divisions.forEach(div => {
    const o = document.createElement("option");
    o.value = div.id; o.textContent = div.icon + " " + div.name;
    el.appendChild(o);
  });
}

function normalizeUrl(url) {
  url = url.trim();
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  return url;
}

async function saveLink() {
  const title    = document.getElementById("lkTitle").value.trim();
  const url      = document.getElementById("lkUrl").value.trim();
  const category = document.getElementById("lkCategory").value;
  const divisi   = document.getElementById("lkDivisi").value;
  const note     = document.getElementById("lkNote").value.trim();

  if (!title || !url) { showToast("⚠️ Judul dan URL wajib diisi!"); return; }

  const finalUrl = normalizeUrl(url);

  if (activeLinkId) {
    const link = dashLinks.find(l => l.id === activeLinkId);
    link.title = title; link.url = finalUrl; link.category = category; link.divisi = divisi; link.note = note;
  } else {
    dashLinks.push({ id: "lk" + Date.now(), title, url: finalUrl, category, divisi, note, createdAt: new Date().toISOString() });
  }

  closeLinkModal();
  renderLinks();
  await pushData();
  showToast(activeLinkId ? "✅ Link diperbarui!" : "✅ Link ditambahkan!");
}

async function deleteCurrentLink() {
  if (!activeLinkId) return;
  if (!confirm("Hapus link ini?")) return;
  dashLinks = dashLinks.filter(l => l.id !== activeLinkId);
  closeLinkModal();
  renderLinks();
  await pushData();
  showToast("🗑️ Link dihapus.");
}

async function deleteLinkDirect(linkId) {
  if (!confirm("Hapus link ini?")) return;
  dashLinks = dashLinks.filter(l => l.id !== linkId);
  renderLinks();
  await pushData();
  showToast("🗑️ Link dihapus.");
}

function filterLinks(cat) {
  activeLinkFilter = cat;
  document.querySelectorAll(".link-cat-chip").forEach(chip => {
    chip.classList.toggle("active", chip.dataset.cat === cat);
  });
  renderLinks();
}

function renderLinks() {
  const grid = document.getElementById("linksGrid");
  if (!grid) return;

  let rows = [...dashLinks];
  if (activeLinkFilter) rows = rows.filter(l => l.category === activeLinkFilter);
  rows.sort((a,b) => (b.createdAt||"").localeCompare(a.createdAt||""));

  if (!rows.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <div class="empty-icon">🔗</div>
      Belum ada link. Klik "➕ Tambah Link" untuk menambahkan spreadsheet, dokumen, atau referensi lainnya.
    </div>`;
    return;
  }

  const divMap = Object.fromEntries(divisions.map(d => [d.id, d.icon + " " + d.name]));

  grid.innerHTML = rows.map(l => {
    let hostname = "";
    try { hostname = new URL(l.url).hostname.replace("www.",""); } catch(e) { hostname = l.url; }
    const catColor = LINK_CAT_COLOR[l.category] || "#7F8C8D";
    const catLabel = LINK_CAT_LABEL[l.category] || l.category;
    return `
      <div class="link-card">
        <div class="link-card-top">
          <span class="link-cat-badge" style="background:${catColor}1A;color:${catColor};border-color:${catColor}55">${catLabel}</span>
          <div class="link-card-actions">
            <button class="btn-icon" onclick="openEditLinkModal('${l.id}')" title="Edit">✏️</button>
            <button class="btn-icon btn-danger" onclick="deleteLinkDirect('${l.id}')" title="Hapus">🗑️</button>
          </div>
        </div>
        <a href="${l.url}" target="_blank" rel="noopener noreferrer" class="link-card-title-link">
          <div class="link-card-title">${l.title}</div>
        </a>
        <div class="link-card-url">🌐 ${hostname}</div>
        ${l.note ? `<div class="link-card-note">${l.note}</div>` : ""}
        ${l.divisi && divMap[l.divisi] ? `<div class="link-card-divisi">${divMap[l.divisi]}</div>` : ""}
        <a href="${l.url}" target="_blank" rel="noopener noreferrer" class="link-card-open-btn">Buka Link ↗</a>
      </div>`;
  }).join("");
}


function daysBetween(a,b) { return Math.round((new Date(b)-new Date(a))/86400000); }
function formatRp(num) { if(isNaN(num)) return "Rp 0"; return "Rp "+Math.abs(num).toLocaleString("id-ID"); }
function formatDateID(str) {
  if(!str) return "—";
  return new Date(str+"T00:00:00").toLocaleDateString("id-ID",{day:"2-digit",month:"short",year:"numeric"});
}

let toastTimer;
function showToast(msg) {
  let el = document.getElementById("toast");
  if(!el) { el=document.createElement("div"); el.id="toast"; document.body.appendChild(el); }
  el.textContent = msg; el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
